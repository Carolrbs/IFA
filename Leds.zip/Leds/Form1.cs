﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Leds
{
     public partial class Form1 : Form
    {// Variáveis de Lógica e Controles
        private Luz luz;

        // Arrays de Controles (Uso INTERNO para inicialização e Conexão de Eventos)
        private PictureBox[] pics;
        private CheckBox[] ckbs;
        private Button[] btnOn;
        private Button[] btnOff;

        // Variáveis de Imagem
        private Image imgAcesa;
        private Image imgApagada;

        public Form1()
        {
            InitializeComponent();
            
            
            Paralela.Escrever(888, 255);

            luz = new Luz();

            // Inicializa Arrays de Controles  
            pics = new PictureBox[] { pic_luz1, pic_luz2, pic_luz3, pic_luz4, pic_luz5, pic_luz6, pic_luz7, pic_luz8 };
            ckbs = new CheckBox[] { ckb_led1, ckb_led2, ckb_led3, ckb_led4, ckb_led5, ckb_led6, ckb_led7, ckb_led8 };
            btnOn = new Button[] { btn_on_1, btn_on_2, btn_on_3, btn_on_4, btn_on_5, btn_on_6, btn_on_7, btn_on_8 };
            btnOff = new Button[] { btn_off_1, btn_off_2, btn_off_3, btn_off_4, btn_off_5, btn_off_6, btn_off_7, btn_off_8 };

            // Imagens 
            imgAcesa = Properties.Resources.Luz_acesa;
            imgApagada = Properties.Resources.Luz_apagada;

            ConectarEventos();//eventos
            AtualizaInterface();
        }

        private void ConectarEventos()
        {
            for (int i = 0; i < 8; i++)
            {

                btnOn[i].Click += BtnOnOff_Click;
                btnOff[i].Click += BtnOnOff_Click;

                ckbs[i].CheckedChanged += CkbLed_CheckedChanged;
            }
        }

        private int GetLedIndexFromControlName(string name)
        {
            int lastIndex = name.Length - 1;
            if (lastIndex >= 0 && char.IsDigit(name[lastIndex]))
            {
                if (int.TryParse(name.Substring(lastIndex, 1), out int index))
                {
                    return index;
                }
            }
            return -1;
        }

        private void BtnOnOff_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int index = GetLedIndexFromControlName(btn.Name);

            if (index != -1)
            {
                if (btn.Name.Contains("btn_on"))
                {
                    luz.Acender(index);
                    lbl_IndicarValor.Text = $"LED {index} ligado por ON.";
                }
                else if (btn.Name.Contains("btn_off"))
                {
                    luz.Apagar(index);
                    lbl_IndicarValor.Text = $"LED {index} desligado por OFF.";
                }

                AtualizaInterface();
            }
        }

        private void CkbLed_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chk = sender as CheckBox;
            int index = GetLedIndexFromControlName(chk.Name);

            if (index != -1)
            {
                if (chk.Checked) luz.Acender(index);
                else luz.Apagar(index);

                AtualizaInterface();
            }
        }
        private void AtualizaInterface()
        {
            byte dado = luz.Getdados();

            Paralela.Escrever(888, dado);

            // 1. Atualiza Textos
            txtDadoDec.Text = dado.ToString();
            txtDadoBin.Text = Convert.ToString(dado, 2).PadLeft(8, '0');
            txtDadoHex.Text = Convert.ToString(dado, 16).ToUpper().PadLeft(2, '0');

            // LED 1
            bool aceso1 = luz.Getled(1);
            pic_luz1.Image = aceso1 ? imgAcesa : imgApagada;
            ckb_led1.CheckedChanged -= CkbLed_CheckedChanged;
            ckb_led1.Checked = aceso1;
            ckb_led1.CheckedChanged += CkbLed_CheckedChanged;

            // LED 2
            bool aceso2 = luz.Getled(2);
            pic_luz2.Image = aceso2 ? imgAcesa : imgApagada;
            ckb_led2.CheckedChanged -= CkbLed_CheckedChanged;
            ckb_led2.Checked = aceso2;
            ckb_led2.CheckedChanged += CkbLed_CheckedChanged;

            // LED 3
            bool aceso3 = luz.Getled(3);
            pic_luz3.Image = aceso3 ? imgAcesa : imgApagada;
            ckb_led3.CheckedChanged -= CkbLed_CheckedChanged;
            ckb_led3.Checked = aceso3;
            ckb_led3.CheckedChanged += CkbLed_CheckedChanged;

            // LED 4
            bool aceso4 = luz.Getled(4);
            pic_luz4.Image = aceso4 ? imgAcesa : imgApagada;
            ckb_led4.CheckedChanged -= CkbLed_CheckedChanged;
            ckb_led4.Checked = aceso4;
            ckb_led4.CheckedChanged += CkbLed_CheckedChanged;

            // LED 5
            bool aceso5 = luz.Getled(5);
            pic_luz5.Image = aceso5 ? imgAcesa : imgApagada;
            ckb_led5.CheckedChanged -= CkbLed_CheckedChanged;
            ckb_led5.Checked = aceso5;
            ckb_led5.CheckedChanged += CkbLed_CheckedChanged;

            // LED 6
            bool aceso6 = luz.Getled(6);
            pic_luz6.Image = aceso6 ? imgAcesa : imgApagada;
            ckb_led6.CheckedChanged -= CkbLed_CheckedChanged;
            ckb_led6.Checked = aceso6;
            ckb_led6.CheckedChanged += CkbLed_CheckedChanged;

            // LED 7
            bool aceso7 = luz.Getled(7);
            pic_luz7.Image = aceso7 ? imgAcesa : imgApagada;
            ckb_led7.CheckedChanged -= CkbLed_CheckedChanged;
            ckb_led7.Checked = aceso7;
            ckb_led7.CheckedChanged += CkbLed_CheckedChanged;

            // LED 8
            bool aceso8 = luz.Getled(8);
            pic_luz8.Image = aceso8 ? imgAcesa : imgApagada;
            ckb_led8.CheckedChanged -= CkbLed_CheckedChanged;
            ckb_led8.Checked = aceso8;
            ckb_led8.CheckedChanged += CkbLed_CheckedChanged;
        }
        private void clicou(object sender, EventArgs e)
        {
        }
        private void btn_on_8_Click(object sender, EventArgs e)
        {
            BtnOnOff_Click(sender, e);
        }

        private void btn_off_8_Click(object sender, EventArgs e)
        {
            BtnOnOff_Click(sender, e);
        }
        private void label1_Click(object sender, EventArgs e)
        {
       
        }
        private void Form1_Load(object sender, EventArgs e) { }
        private void lbl_IndicarValor_Click(object sender, EventArgs e) { }
    }
}