﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Leds
{
    internal class Luz
    {
            private byte dados;

        public Luz()
        {
            dados = 0;
        }

        public byte Getdados()
        {
            return dados;
        }

        public bool Getled(int led)
        {
            if (led < 1 || led > 8) return false;
            return (dados & (1 << (led - 1))) != 0;
        }

        public void Acender(int led)
        {
            if (led < 1 || led > 8) return;
            dados = (byte)(dados | (1 << (led - 1)));
        }

        public void Apagar(int led)
        {
            if (led < 1 || led > 8) return;
            dados = (byte)(dados & ~(1 << (led - 1)));
        }

        public void AcenderTodos()
        {
            dados = 0xFF;
        }

        public void ApagarTodos()
        {
            dados = 0x00;
        }
    }
}