﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Runtime.InteropServices; // tem que colocar

namespace Leds
{
    internal class Paralela
    {
        [DllImport("inpout32.dll", EntryPoint = "Out32")]
        public static extern void Escrever(int endereco, byte valor);
    }
}