﻿namespace Leds
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pic_luz8 = new System.Windows.Forms.PictureBox();
            this.ckb_led8 = new System.Windows.Forms.CheckBox();
            this.btn_off_8 = new System.Windows.Forms.Button();
            this.lbl_led_8 = new System.Windows.Forms.Label();
            this.btn_on_8 = new System.Windows.Forms.Button();
            this.pic_luz6 = new System.Windows.Forms.PictureBox();
            this.pic_luz7 = new System.Windows.Forms.PictureBox();
            this.pic_luz5 = new System.Windows.Forms.PictureBox();
            this.pic_luz4 = new System.Windows.Forms.PictureBox();
            this.pic_luz3 = new System.Windows.Forms.PictureBox();
            this.pic_luz2 = new System.Windows.Forms.PictureBox();
            this.pic_luz1 = new System.Windows.Forms.PictureBox();
            this.ckb_led7 = new System.Windows.Forms.CheckBox();
            this.ckb_led6 = new System.Windows.Forms.CheckBox();
            this.ckb_led5 = new System.Windows.Forms.CheckBox();
            this.ckb_led4 = new System.Windows.Forms.CheckBox();
            this.ckb_led3 = new System.Windows.Forms.CheckBox();
            this.ckb_led2 = new System.Windows.Forms.CheckBox();
            this.ckb_led1 = new System.Windows.Forms.CheckBox();
            this.btn_off_1 = new System.Windows.Forms.Button();
            this.lbl_led_1 = new System.Windows.Forms.Label();
            this.btn_on_1 = new System.Windows.Forms.Button();
            this.btn_off_2 = new System.Windows.Forms.Button();
            this.lbl_led_2 = new System.Windows.Forms.Label();
            this.btn_on_2 = new System.Windows.Forms.Button();
            this.btn_off_3 = new System.Windows.Forms.Button();
            this.lbl_led_3 = new System.Windows.Forms.Label();
            this.btn_on_3 = new System.Windows.Forms.Button();
            this.btn_off_4 = new System.Windows.Forms.Button();
            this.lbl_led_4 = new System.Windows.Forms.Label();
            this.btn_on_4 = new System.Windows.Forms.Button();
            this.btn_off_5 = new System.Windows.Forms.Button();
            this.lbl_led_5 = new System.Windows.Forms.Label();
            this.btn_on_5 = new System.Windows.Forms.Button();
            this.btn_off_6 = new System.Windows.Forms.Button();
            this.lbl_led_6 = new System.Windows.Forms.Label();
            this.btn_on_6 = new System.Windows.Forms.Button();
            this.btn_off_7 = new System.Windows.Forms.Button();
            this.lbl_led_7 = new System.Windows.Forms.Label();
            this.btn_on_7 = new System.Windows.Forms.Button();
            this.txtDadoBin = new System.Windows.Forms.TextBox();
            this.txtDadoDec = new System.Windows.Forms.TextBox();
            this.lbl_IndicarValor = new System.Windows.Forms.Label();
            this.txtDadoHex = new System.Windows.Forms.TextBox();
            this.textDecimal = new System.Windows.Forms.Label();
            this.TextBI = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz1)).BeginInit();
            this.SuspendLayout();
            // 
            // pic_luz8
            // 
            this.pic_luz8.Location = new System.Drawing.Point(21, 27);
            this.pic_luz8.Margin = new System.Windows.Forms.Padding(4);
            this.pic_luz8.Name = "pic_luz8";
            this.pic_luz8.Size = new System.Drawing.Size(61, 62);
            this.pic_luz8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_luz8.TabIndex = 78;
            this.pic_luz8.TabStop = false;
            // 
            // ckb_led8
            // 
            this.ckb_led8.AutoSize = true;
            this.ckb_led8.Location = new System.Drawing.Point(45, 209);
            this.ckb_led8.Margin = new System.Windows.Forms.Padding(4);
            this.ckb_led8.Name = "ckb_led8";
            this.ckb_led8.Size = new System.Drawing.Size(18, 17);
            this.ckb_led8.TabIndex = 82;
            this.ckb_led8.UseVisualStyleBackColor = true;
            // 
            // btn_off_8
            // 
            this.btn_off_8.Location = new System.Drawing.Point(22, 173);
            this.btn_off_8.Margin = new System.Windows.Forms.Padding(4);
            this.btn_off_8.Name = "btn_off_8";
            this.btn_off_8.Size = new System.Drawing.Size(61, 28);
            this.btn_off_8.TabIndex = 81;
            this.btn_off_8.Text = "Off";
            this.btn_off_8.UseVisualStyleBackColor = true;
            this.btn_off_8.Click += new System.EventHandler(this.btn_off_8_Click);
            // 
            // lbl_led_8
            // 
            this.lbl_led_8.AutoSize = true;
            this.lbl_led_8.Location = new System.Drawing.Point(38, 108);
            this.lbl_led_8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_led_8.Name = "lbl_led_8";
            this.lbl_led_8.Size = new System.Drawing.Size(40, 16);
            this.lbl_led_8.TabIndex = 80;
            this.lbl_led_8.Text = "Led 8";
            // 
            // btn_on_8
            // 
            this.btn_on_8.Location = new System.Drawing.Point(21, 137);
            this.btn_on_8.Margin = new System.Windows.Forms.Padding(4);
            this.btn_on_8.Name = "btn_on_8";
            this.btn_on_8.Size = new System.Drawing.Size(61, 28);
            this.btn_on_8.TabIndex = 79;
            this.btn_on_8.Text = "On";
            this.btn_on_8.UseVisualStyleBackColor = true;
            this.btn_on_8.Click += new System.EventHandler(this.btn_on_8_Click);
            // 
            // pic_luz6
            // 
            this.pic_luz6.Location = new System.Drawing.Point(161, 27);
            this.pic_luz6.Margin = new System.Windows.Forms.Padding(4);
            this.pic_luz6.Name = "pic_luz6";
            this.pic_luz6.Size = new System.Drawing.Size(61, 62);
            this.pic_luz6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_luz6.TabIndex = 116;
            this.pic_luz6.TabStop = false;
            // 
            // pic_luz7
            // 
            this.pic_luz7.Location = new System.Drawing.Point(91, 27);
            this.pic_luz7.Margin = new System.Windows.Forms.Padding(4);
            this.pic_luz7.Name = "pic_luz7";
            this.pic_luz7.Size = new System.Drawing.Size(61, 62);
            this.pic_luz7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_luz7.TabIndex = 117;
            this.pic_luz7.TabStop = false;
            // 
            // pic_luz5
            // 
            this.pic_luz5.Location = new System.Drawing.Point(230, 27);
            this.pic_luz5.Margin = new System.Windows.Forms.Padding(4);
            this.pic_luz5.Name = "pic_luz5";
            this.pic_luz5.Size = new System.Drawing.Size(61, 62);
            this.pic_luz5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_luz5.TabIndex = 115;
            this.pic_luz5.TabStop = false;
            // 
            // pic_luz4
            // 
            this.pic_luz4.Location = new System.Drawing.Point(299, 27);
            this.pic_luz4.Margin = new System.Windows.Forms.Padding(4);
            this.pic_luz4.Name = "pic_luz4";
            this.pic_luz4.Size = new System.Drawing.Size(61, 62);
            this.pic_luz4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_luz4.TabIndex = 114;
            this.pic_luz4.TabStop = false;
            // 
            // pic_luz3
            // 
            this.pic_luz3.Location = new System.Drawing.Point(369, 27);
            this.pic_luz3.Margin = new System.Windows.Forms.Padding(4);
            this.pic_luz3.Name = "pic_luz3";
            this.pic_luz3.Size = new System.Drawing.Size(61, 62);
            this.pic_luz3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_luz3.TabIndex = 113;
            this.pic_luz3.TabStop = false;
            // 
            // pic_luz2
            // 
            this.pic_luz2.Location = new System.Drawing.Point(438, 27);
            this.pic_luz2.Margin = new System.Windows.Forms.Padding(4);
            this.pic_luz2.Name = "pic_luz2";
            this.pic_luz2.Size = new System.Drawing.Size(61, 62);
            this.pic_luz2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_luz2.TabIndex = 112;
            this.pic_luz2.TabStop = false;
            // 
            // pic_luz1
            // 
            this.pic_luz1.Location = new System.Drawing.Point(507, 28);
            this.pic_luz1.Margin = new System.Windows.Forms.Padding(4);
            this.pic_luz1.Name = "pic_luz1";
            this.pic_luz1.Size = new System.Drawing.Size(61, 62);
            this.pic_luz1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_luz1.TabIndex = 111;
            this.pic_luz1.TabStop = false;
            // 
            // ckb_led7
            // 
            this.ckb_led7.AutoSize = true;
            this.ckb_led7.Location = new System.Drawing.Point(114, 209);
            this.ckb_led7.Margin = new System.Windows.Forms.Padding(4);
            this.ckb_led7.Name = "ckb_led7";
            this.ckb_led7.Size = new System.Drawing.Size(18, 17);
            this.ckb_led7.TabIndex = 110;
            this.ckb_led7.UseVisualStyleBackColor = true;
            // 
            // ckb_led6
            // 
            this.ckb_led6.AutoSize = true;
            this.ckb_led6.Location = new System.Drawing.Point(183, 209);
            this.ckb_led6.Margin = new System.Windows.Forms.Padding(4);
            this.ckb_led6.Name = "ckb_led6";
            this.ckb_led6.Size = new System.Drawing.Size(18, 17);
            this.ckb_led6.TabIndex = 109;
            this.ckb_led6.UseVisualStyleBackColor = true;
            // 
            // ckb_led5
            // 
            this.ckb_led5.AutoSize = true;
            this.ckb_led5.Location = new System.Drawing.Point(253, 209);
            this.ckb_led5.Margin = new System.Windows.Forms.Padding(4);
            this.ckb_led5.Name = "ckb_led5";
            this.ckb_led5.Size = new System.Drawing.Size(18, 17);
            this.ckb_led5.TabIndex = 108;
            this.ckb_led5.UseVisualStyleBackColor = true;
            // 
            // ckb_led4
            // 
            this.ckb_led4.AutoSize = true;
            this.ckb_led4.Location = new System.Drawing.Point(322, 209);
            this.ckb_led4.Margin = new System.Windows.Forms.Padding(4);
            this.ckb_led4.Name = "ckb_led4";
            this.ckb_led4.Size = new System.Drawing.Size(18, 17);
            this.ckb_led4.TabIndex = 107;
            this.ckb_led4.UseVisualStyleBackColor = true;
            // 
            // ckb_led3
            // 
            this.ckb_led3.AutoSize = true;
            this.ckb_led3.Location = new System.Drawing.Point(391, 209);
            this.ckb_led3.Margin = new System.Windows.Forms.Padding(4);
            this.ckb_led3.Name = "ckb_led3";
            this.ckb_led3.Size = new System.Drawing.Size(18, 17);
            this.ckb_led3.TabIndex = 105;
            this.ckb_led3.UseVisualStyleBackColor = true;
            // 
            // ckb_led2
            // 
            this.ckb_led2.AutoSize = true;
            this.ckb_led2.Location = new System.Drawing.Point(461, 209);
            this.ckb_led2.Margin = new System.Windows.Forms.Padding(4);
            this.ckb_led2.Name = "ckb_led2";
            this.ckb_led2.Size = new System.Drawing.Size(18, 17);
            this.ckb_led2.TabIndex = 106;
            this.ckb_led2.UseVisualStyleBackColor = true;
            // 
            // ckb_led1
            // 
            this.ckb_led1.AutoSize = true;
            this.ckb_led1.Location = new System.Drawing.Point(530, 209);
            this.ckb_led1.Margin = new System.Windows.Forms.Padding(4);
            this.ckb_led1.Name = "ckb_led1";
            this.ckb_led1.Size = new System.Drawing.Size(18, 17);
            this.ckb_led1.TabIndex = 104;
            this.ckb_led1.UseVisualStyleBackColor = true;
            // 
            // btn_off_1
            // 
            this.btn_off_1.Location = new System.Drawing.Point(507, 173);
            this.btn_off_1.Margin = new System.Windows.Forms.Padding(4);
            this.btn_off_1.Name = "btn_off_1";
            this.btn_off_1.Size = new System.Drawing.Size(61, 28);
            this.btn_off_1.TabIndex = 103;
            this.btn_off_1.Text = "Off";
            this.btn_off_1.UseVisualStyleBackColor = true;
            // 
            // lbl_led_1
            // 
            this.lbl_led_1.AutoSize = true;
            this.lbl_led_1.Location = new System.Drawing.Point(518, 108);
            this.lbl_led_1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_led_1.Name = "lbl_led_1";
            this.lbl_led_1.Size = new System.Drawing.Size(40, 16);
            this.lbl_led_1.TabIndex = 102;
            this.lbl_led_1.Text = "Led 1";
            // 
            // btn_on_1
            // 
            this.btn_on_1.Location = new System.Drawing.Point(507, 137);
            this.btn_on_1.Margin = new System.Windows.Forms.Padding(4);
            this.btn_on_1.Name = "btn_on_1";
            this.btn_on_1.Size = new System.Drawing.Size(61, 28);
            this.btn_on_1.TabIndex = 101;
            this.btn_on_1.Text = "On";
            this.btn_on_1.UseVisualStyleBackColor = true;
            // 
            // btn_off_2
            // 
            this.btn_off_2.Location = new System.Drawing.Point(438, 173);
            this.btn_off_2.Margin = new System.Windows.Forms.Padding(4);
            this.btn_off_2.Name = "btn_off_2";
            this.btn_off_2.Size = new System.Drawing.Size(61, 28);
            this.btn_off_2.TabIndex = 100;
            this.btn_off_2.Text = "Off";
            this.btn_off_2.UseVisualStyleBackColor = true;
            // 
            // lbl_led_2
            // 
            this.lbl_led_2.AutoSize = true;
            this.lbl_led_2.Location = new System.Drawing.Point(449, 108);
            this.lbl_led_2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_led_2.Name = "lbl_led_2";
            this.lbl_led_2.Size = new System.Drawing.Size(40, 16);
            this.lbl_led_2.TabIndex = 99;
            this.lbl_led_2.Text = "Led 2";
            // 
            // btn_on_2
            // 
            this.btn_on_2.Location = new System.Drawing.Point(438, 137);
            this.btn_on_2.Margin = new System.Windows.Forms.Padding(4);
            this.btn_on_2.Name = "btn_on_2";
            this.btn_on_2.Size = new System.Drawing.Size(61, 28);
            this.btn_on_2.TabIndex = 98;
            this.btn_on_2.Text = "On";
            this.btn_on_2.UseVisualStyleBackColor = true;
            // 
            // btn_off_3
            // 
            this.btn_off_3.Location = new System.Drawing.Point(369, 173);
            this.btn_off_3.Margin = new System.Windows.Forms.Padding(4);
            this.btn_off_3.Name = "btn_off_3";
            this.btn_off_3.Size = new System.Drawing.Size(61, 28);
            this.btn_off_3.TabIndex = 97;
            this.btn_off_3.Text = "Off";
            this.btn_off_3.UseVisualStyleBackColor = true;
            // 
            // lbl_led_3
            // 
            this.lbl_led_3.AutoSize = true;
            this.lbl_led_3.Location = new System.Drawing.Point(379, 108);
            this.lbl_led_3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_led_3.Name = "lbl_led_3";
            this.lbl_led_3.Size = new System.Drawing.Size(40, 16);
            this.lbl_led_3.TabIndex = 96;
            this.lbl_led_3.Text = "Led 3";
            // 
            // btn_on_3
            // 
            this.btn_on_3.Location = new System.Drawing.Point(369, 137);
            this.btn_on_3.Margin = new System.Windows.Forms.Padding(4);
            this.btn_on_3.Name = "btn_on_3";
            this.btn_on_3.Size = new System.Drawing.Size(61, 28);
            this.btn_on_3.TabIndex = 95;
            this.btn_on_3.Text = "On";
            this.btn_on_3.UseVisualStyleBackColor = true;
            // 
            // btn_off_4
            // 
            this.btn_off_4.Location = new System.Drawing.Point(299, 173);
            this.btn_off_4.Margin = new System.Windows.Forms.Padding(4);
            this.btn_off_4.Name = "btn_off_4";
            this.btn_off_4.Size = new System.Drawing.Size(61, 28);
            this.btn_off_4.TabIndex = 94;
            this.btn_off_4.Text = "Off";
            this.btn_off_4.UseVisualStyleBackColor = true;
            // 
            // lbl_led_4
            // 
            this.lbl_led_4.AutoSize = true;
            this.lbl_led_4.Location = new System.Drawing.Point(310, 108);
            this.lbl_led_4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_led_4.Name = "lbl_led_4";
            this.lbl_led_4.Size = new System.Drawing.Size(40, 16);
            this.lbl_led_4.TabIndex = 93;
            this.lbl_led_4.Text = "Led 4";
            // 
            // btn_on_4
            // 
            this.btn_on_4.Location = new System.Drawing.Point(299, 137);
            this.btn_on_4.Margin = new System.Windows.Forms.Padding(4);
            this.btn_on_4.Name = "btn_on_4";
            this.btn_on_4.Size = new System.Drawing.Size(61, 28);
            this.btn_on_4.TabIndex = 92;
            this.btn_on_4.Text = "On";
            this.btn_on_4.UseVisualStyleBackColor = true;
            // 
            // btn_off_5
            // 
            this.btn_off_5.Location = new System.Drawing.Point(230, 173);
            this.btn_off_5.Margin = new System.Windows.Forms.Padding(4);
            this.btn_off_5.Name = "btn_off_5";
            this.btn_off_5.Size = new System.Drawing.Size(61, 28);
            this.btn_off_5.TabIndex = 91;
            this.btn_off_5.Text = "Off";
            this.btn_off_5.UseVisualStyleBackColor = true;
            // 
            // lbl_led_5
            // 
            this.lbl_led_5.AutoSize = true;
            this.lbl_led_5.Location = new System.Drawing.Point(241, 108);
            this.lbl_led_5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_led_5.Name = "lbl_led_5";
            this.lbl_led_5.Size = new System.Drawing.Size(40, 16);
            this.lbl_led_5.TabIndex = 90;
            this.lbl_led_5.Text = "Led 5";
            // 
            // btn_on_5
            // 
            this.btn_on_5.Location = new System.Drawing.Point(230, 137);
            this.btn_on_5.Margin = new System.Windows.Forms.Padding(4);
            this.btn_on_5.Name = "btn_on_5";
            this.btn_on_5.Size = new System.Drawing.Size(61, 28);
            this.btn_on_5.TabIndex = 89;
            this.btn_on_5.Text = "On";
            this.btn_on_5.UseVisualStyleBackColor = true;
            // 
            // btn_off_6
            // 
            this.btn_off_6.Location = new System.Drawing.Point(161, 173);
            this.btn_off_6.Margin = new System.Windows.Forms.Padding(4);
            this.btn_off_6.Name = "btn_off_6";
            this.btn_off_6.Size = new System.Drawing.Size(61, 28);
            this.btn_off_6.TabIndex = 88;
            this.btn_off_6.Text = "Off";
            this.btn_off_6.UseVisualStyleBackColor = true;
            // 
            // lbl_led_6
            // 
            this.lbl_led_6.AutoSize = true;
            this.lbl_led_6.Location = new System.Drawing.Point(171, 108);
            this.lbl_led_6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_led_6.Name = "lbl_led_6";
            this.lbl_led_6.Size = new System.Drawing.Size(40, 16);
            this.lbl_led_6.TabIndex = 87;
            this.lbl_led_6.Text = "Led 6";
            // 
            // btn_on_6
            // 
            this.btn_on_6.Location = new System.Drawing.Point(161, 137);
            this.btn_on_6.Margin = new System.Windows.Forms.Padding(4);
            this.btn_on_6.Name = "btn_on_6";
            this.btn_on_6.Size = new System.Drawing.Size(61, 28);
            this.btn_on_6.TabIndex = 86;
            this.btn_on_6.Text = "On";
            this.btn_on_6.UseVisualStyleBackColor = true;
            // 
            // btn_off_7
            // 
            this.btn_off_7.Location = new System.Drawing.Point(91, 173);
            this.btn_off_7.Margin = new System.Windows.Forms.Padding(4);
            this.btn_off_7.Name = "btn_off_7";
            this.btn_off_7.Size = new System.Drawing.Size(61, 28);
            this.btn_off_7.TabIndex = 85;
            this.btn_off_7.Text = "Off";
            this.btn_off_7.UseVisualStyleBackColor = true;
            // 
            // lbl_led_7
            // 
            this.lbl_led_7.AutoSize = true;
            this.lbl_led_7.Location = new System.Drawing.Point(102, 108);
            this.lbl_led_7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_led_7.Name = "lbl_led_7";
            this.lbl_led_7.Size = new System.Drawing.Size(40, 16);
            this.lbl_led_7.TabIndex = 84;
            this.lbl_led_7.Text = "Led 7";
            // 
            // btn_on_7
            // 
            this.btn_on_7.Location = new System.Drawing.Point(91, 137);
            this.btn_on_7.Margin = new System.Windows.Forms.Padding(4);
            this.btn_on_7.Name = "btn_on_7";
            this.btn_on_7.Size = new System.Drawing.Size(61, 28);
            this.btn_on_7.TabIndex = 83;
            this.btn_on_7.Text = "On";
            this.btn_on_7.UseVisualStyleBackColor = true;
            // 
            // txtDadoBin
            // 
            this.txtDadoBin.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.txtDadoBin.Location = new System.Drawing.Point(186, 318);
            this.txtDadoBin.Margin = new System.Windows.Forms.Padding(4);
            this.txtDadoBin.Name = "txtDadoBin";
            this.txtDadoBin.Size = new System.Drawing.Size(132, 22);
            this.txtDadoBin.TabIndex = 120;
            // 
            // txtDadoDec
            // 
            this.txtDadoDec.Location = new System.Drawing.Point(25, 318);
            this.txtDadoDec.Margin = new System.Windows.Forms.Padding(4);
            this.txtDadoDec.Name = "txtDadoDec";
            this.txtDadoDec.Size = new System.Drawing.Size(132, 22);
            this.txtDadoDec.TabIndex = 119;
            // 
            // lbl_IndicarValor
            // 
            this.lbl_IndicarValor.AutoSize = true;
            this.lbl_IndicarValor.Location = new System.Drawing.Point(30, 275);
            this.lbl_IndicarValor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_IndicarValor.Name = "lbl_IndicarValor";
            this.lbl_IndicarValor.Size = new System.Drawing.Size(48, 16);
            this.lbl_IndicarValor.TabIndex = 118;
            this.lbl_IndicarValor.Text = "Dados";
            this.lbl_IndicarValor.Click += new System.EventHandler(this.lbl_IndicarValor_Click);
            // 
            // txtDadoHex
            // 
            this.txtDadoHex.Location = new System.Drawing.Point(347, 318);
            this.txtDadoHex.Margin = new System.Windows.Forms.Padding(4);
            this.txtDadoHex.Name = "txtDadoHex";
            this.txtDadoHex.Size = new System.Drawing.Size(132, 22);
            this.txtDadoHex.TabIndex = 121;
            // 
            // textDecimal
            // 
            this.textDecimal.AutoSize = true;
            this.textDecimal.Location = new System.Drawing.Point(23, 344);
            this.textDecimal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.textDecimal.Name = "textDecimal";
            this.textDecimal.Size = new System.Drawing.Size(130, 16);
            this.textDecimal.TabIndex = 122;
            this.textDecimal.Text = "Numero em Decimal";
            this.textDecimal.Click += new System.EventHandler(this.label1_Click);
            // 
            // TextBI
            // 
            this.TextBI.AutoSize = true;
            this.TextBI.Location = new System.Drawing.Point(188, 344);
            this.TextBI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TextBI.Name = "TextBI";
            this.TextBI.Size = new System.Drawing.Size(122, 16);
            this.TextBI.TabIndex = 123;
            this.TextBI.Text = "Numero em Binário";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(344, 344);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 16);
            this.label1.TabIndex = 124;
            this.label1.Text = "Numero em Hexadecimal";
           
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 516);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TextBI);
            this.Controls.Add(this.textDecimal);
            this.Controls.Add(this.txtDadoHex);
            this.Controls.Add(this.txtDadoBin);
            this.Controls.Add(this.txtDadoDec);
            this.Controls.Add(this.lbl_IndicarValor);
            this.Controls.Add(this.pic_luz6);
            this.Controls.Add(this.pic_luz7);
            this.Controls.Add(this.pic_luz5);
            this.Controls.Add(this.pic_luz4);
            this.Controls.Add(this.pic_luz3);
            this.Controls.Add(this.pic_luz2);
            this.Controls.Add(this.pic_luz1);
            this.Controls.Add(this.ckb_led7);
            this.Controls.Add(this.ckb_led6);
            this.Controls.Add(this.ckb_led5);
            this.Controls.Add(this.ckb_led4);
            this.Controls.Add(this.ckb_led3);
            this.Controls.Add(this.ckb_led2);
            this.Controls.Add(this.ckb_led1);
            this.Controls.Add(this.btn_off_1);
            this.Controls.Add(this.lbl_led_1);
            this.Controls.Add(this.btn_on_1);
            this.Controls.Add(this.btn_off_2);
            this.Controls.Add(this.lbl_led_2);
            this.Controls.Add(this.btn_on_2);
            this.Controls.Add(this.btn_off_3);
            this.Controls.Add(this.lbl_led_3);
            this.Controls.Add(this.btn_on_3);
            this.Controls.Add(this.btn_off_4);
            this.Controls.Add(this.lbl_led_4);
            this.Controls.Add(this.btn_on_4);
            this.Controls.Add(this.btn_off_5);
            this.Controls.Add(this.lbl_led_5);
            this.Controls.Add(this.btn_on_5);
            this.Controls.Add(this.btn_off_6);
            this.Controls.Add(this.lbl_led_6);
            this.Controls.Add(this.btn_on_6);
            this.Controls.Add(this.btn_off_7);
            this.Controls.Add(this.lbl_led_7);
            this.Controls.Add(this.btn_on_7);
            this.Controls.Add(this.ckb_led8);
            this.Controls.Add(this.btn_off_8);
            this.Controls.Add(this.lbl_led_8);
            this.Controls.Add(this.btn_on_8);
            this.Controls.Add(this.pic_luz8);
            this.Name = "Form1";
            this.Text = "Acenda as luzes";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_luz1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pic_luz8;
        private System.Windows.Forms.CheckBox ckb_led8;
        private System.Windows.Forms.Button btn_off_8;
        private System.Windows.Forms.Label lbl_led_8;
        private System.Windows.Forms.Button btn_on_8;
        private System.Windows.Forms.PictureBox pic_luz6;
        private System.Windows.Forms.PictureBox pic_luz7;
        private System.Windows.Forms.PictureBox pic_luz5;
        private System.Windows.Forms.PictureBox pic_luz4;
        private System.Windows.Forms.PictureBox pic_luz3;
        private System.Windows.Forms.PictureBox pic_luz2;
        private System.Windows.Forms.PictureBox pic_luz1;
        private System.Windows.Forms.CheckBox ckb_led7;
        private System.Windows.Forms.CheckBox ckb_led6;
        private System.Windows.Forms.CheckBox ckb_led5;
        private System.Windows.Forms.CheckBox ckb_led4;
        private System.Windows.Forms.CheckBox ckb_led3;
        private System.Windows.Forms.CheckBox ckb_led2;
        private System.Windows.Forms.CheckBox ckb_led1;
        private System.Windows.Forms.Button btn_off_1;
        private System.Windows.Forms.Label lbl_led_1;
        private System.Windows.Forms.Button btn_on_1;
        private System.Windows.Forms.Button btn_off_2;
        private System.Windows.Forms.Label lbl_led_2;
        private System.Windows.Forms.Button btn_on_2;
        private System.Windows.Forms.Button btn_off_3;
        private System.Windows.Forms.Label lbl_led_3;
        private System.Windows.Forms.Button btn_on_3;
        private System.Windows.Forms.Button btn_off_4;
        private System.Windows.Forms.Label lbl_led_4;
        private System.Windows.Forms.Button btn_on_4;
        private System.Windows.Forms.Button btn_off_5;
        private System.Windows.Forms.Label lbl_led_5;
        private System.Windows.Forms.Button btn_on_5;
        private System.Windows.Forms.Button btn_off_6;
        private System.Windows.Forms.Label lbl_led_6;
        private System.Windows.Forms.Button btn_on_6;
        private System.Windows.Forms.Button btn_off_7;
        private System.Windows.Forms.Label lbl_led_7;
        private System.Windows.Forms.Button btn_on_7;
        private System.Windows.Forms.TextBox txtDadoBin;
        private System.Windows.Forms.TextBox txtDadoDec;
        private System.Windows.Forms.Label lbl_IndicarValor;
        private System.Windows.Forms.TextBox txtDadoHex;
        private System.Windows.Forms.Label textDecimal;
        private System.Windows.Forms.Label TextBI;
        private System.Windows.Forms.Label label1;
    }
}

