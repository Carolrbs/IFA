﻿namespace Semáforo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Rua1Verd = new System.Windows.Forms.Button();
            this.btn_Rua1Verm = new System.Windows.Forms.Button();
            this.btn_Rua1Amar = new System.Windows.Forms.Button();
            this.btn_Rua2Amar = new System.Windows.Forms.Button();
            this.btn_Rua2Verm = new System.Windows.Forms.Button();
            this.btn_Rua2Verd = new System.Windows.Forms.Button();
            this.pic_rua2 = new System.Windows.Forms.PictureBox();
            this.pic_rua1 = new System.Windows.Forms.PictureBox();
            this.Lbl_Rua1 = new System.Windows.Forms.Label();
            this.Lbl_rua2 = new System.Windows.Forms.Label();
            this.txb_Dado_2 = new System.Windows.Forms.TextBox();
            this.txb_Dados = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.pic_rua2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_rua1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Rua1Verd
            // 
            this.btn_Rua1Verd.Location = new System.Drawing.Point(339, 231);
            this.btn_Rua1Verd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Rua1Verd.Name = "btn_Rua1Verd";
            this.btn_Rua1Verd.Size = new System.Drawing.Size(100, 28);
            this.btn_Rua1Verd.TabIndex = 0;
            this.btn_Rua1Verd.Text = "Verde";
            this.btn_Rua1Verd.UseVisualStyleBackColor = true;
            this.btn_Rua1Verd.Click += new System.EventHandler(this.btn_Rua1Verd_Click);
            // 
            // btn_Rua1Verm
            // 
            this.btn_Rua1Verm.Location = new System.Drawing.Point(339, 133);
            this.btn_Rua1Verm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Rua1Verm.Name = "btn_Rua1Verm";
            this.btn_Rua1Verm.Size = new System.Drawing.Size(100, 28);
            this.btn_Rua1Verm.TabIndex = 1;
            this.btn_Rua1Verm.Text = "Vermelho";
            this.btn_Rua1Verm.UseVisualStyleBackColor = true;
            this.btn_Rua1Verm.Click += new System.EventHandler(this.btn_Rua1Verm_Click);
            // 
            // btn_Rua1Amar
            // 
            this.btn_Rua1Amar.Location = new System.Drawing.Point(339, 180);
            this.btn_Rua1Amar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Rua1Amar.Name = "btn_Rua1Amar";
            this.btn_Rua1Amar.Size = new System.Drawing.Size(100, 28);
            this.btn_Rua1Amar.TabIndex = 2;
            this.btn_Rua1Amar.Text = "Amarelo";
            this.btn_Rua1Amar.UseVisualStyleBackColor = true;
            this.btn_Rua1Amar.Click += new System.EventHandler(this.btn_Rua1Amar_Click);
            // 
            // btn_Rua2Amar
            // 
            this.btn_Rua2Amar.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Rua2Amar.Location = new System.Drawing.Point(860, 180);
            this.btn_Rua2Amar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Rua2Amar.Name = "btn_Rua2Amar";
            this.btn_Rua2Amar.Size = new System.Drawing.Size(100, 28);
            this.btn_Rua2Amar.TabIndex = 5;
            this.btn_Rua2Amar.Text = "Amarelo";
            this.btn_Rua2Amar.UseVisualStyleBackColor = true;
            this.btn_Rua2Amar.Click += new System.EventHandler(this.btn_Rua2Amar_Click);
            // 
            // btn_Rua2Verm
            // 
            this.btn_Rua2Verm.Location = new System.Drawing.Point(860, 133);
            this.btn_Rua2Verm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Rua2Verm.Name = "btn_Rua2Verm";
            this.btn_Rua2Verm.Size = new System.Drawing.Size(100, 28);
            this.btn_Rua2Verm.TabIndex = 4;
            this.btn_Rua2Verm.Text = "Vermelho";
            this.btn_Rua2Verm.UseVisualStyleBackColor = true;
            this.btn_Rua2Verm.Click += new System.EventHandler(this.btn_Rua2Verm_Click);
            // 
            // btn_Rua2Verd
            // 
            this.btn_Rua2Verd.Location = new System.Drawing.Point(860, 231);
            this.btn_Rua2Verd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Rua2Verd.Name = "btn_Rua2Verd";
            this.btn_Rua2Verd.Size = new System.Drawing.Size(100, 28);
            this.btn_Rua2Verd.TabIndex = 3;
            this.btn_Rua2Verd.Text = "Verde";
            this.btn_Rua2Verd.UseVisualStyleBackColor = true;
            this.btn_Rua2Verd.Click += new System.EventHandler(this.btn_Rua2Verd_Click);
            // 
            // pic_rua2
            // 
            this.pic_rua2.Image = global::Semáforo.Properties.Resources.desligado;
            this.pic_rua2.Location = new System.Drawing.Point(616, 133);
            this.pic_rua2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pic_rua2.Name = "pic_rua2";
            this.pic_rua2.Size = new System.Drawing.Size(236, 161);
            this.pic_rua2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_rua2.TabIndex = 7;
            this.pic_rua2.TabStop = false;
            // 
            // pic_rua1
            // 
            this.pic_rua1.Image = global::Semáforo.Properties.Resources.desligado;
            this.pic_rua1.Location = new System.Drawing.Point(95, 133);
            this.pic_rua1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pic_rua1.Name = "pic_rua1";
            this.pic_rua1.Size = new System.Drawing.Size(236, 161);
            this.pic_rua1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_rua1.TabIndex = 8;
            this.pic_rua1.TabStop = false;
            // 
            // Lbl_Rua1
            // 
            this.Lbl_Rua1.AutoSize = true;
            this.Lbl_Rua1.Location = new System.Drawing.Point(184, 93);
            this.Lbl_Rua1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_Rua1.Name = "Lbl_Rua1";
            this.Lbl_Rua1.Size = new System.Drawing.Size(42, 16);
            this.Lbl_Rua1.TabIndex = 9;
            this.Lbl_Rua1.Text = "Rua 1";
            // 
            // Lbl_rua2
            // 
            this.Lbl_rua2.AutoSize = true;
            this.Lbl_rua2.Location = new System.Drawing.Point(683, 93);
            this.Lbl_rua2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_rua2.Name = "Lbl_rua2";
            this.Lbl_rua2.Size = new System.Drawing.Size(42, 16);
            this.Lbl_rua2.TabIndex = 10;
            this.Lbl_rua2.Text = "Rua 2";
            this.Lbl_rua2.Click += new System.EventHandler(this.Lbl_rua2_Click);
            // 
            // txb_Dado_2
            // 
            this.txb_Dado_2.Location = new System.Drawing.Point(188, 391);
            this.txb_Dado_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_Dado_2.Name = "txb_Dado_2";
            this.txb_Dado_2.Size = new System.Drawing.Size(132, 22);
            this.txb_Dado_2.TabIndex = 11;
            // 
            // txb_Dados
            // 
            this.txb_Dados.Location = new System.Drawing.Point(687, 391);
            this.txb_Dados.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txb_Dados.Name = "txb_Dados";
            this.txb_Dados.Size = new System.Drawing.Size(132, 22);
            this.txb_Dados.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(459, 457);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 13;
            this.button1.Text = "Desligar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txb_Dados);
            this.Controls.Add(this.txb_Dado_2);
            this.Controls.Add(this.Lbl_rua2);
            this.Controls.Add(this.Lbl_Rua1);
            this.Controls.Add(this.pic_rua1);
            this.Controls.Add(this.pic_rua2);
            this.Controls.Add(this.btn_Rua2Amar);
            this.Controls.Add(this.btn_Rua2Verm);
            this.Controls.Add(this.btn_Rua2Verd);
            this.Controls.Add(this.btn_Rua1Amar);
            this.Controls.Add(this.btn_Rua1Verm);
            this.Controls.Add(this.btn_Rua1Verd);
            this.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pic_rua2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_rua1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Rua1Verd;
        private System.Windows.Forms.Button btn_Rua1Verm;
        private System.Windows.Forms.Button btn_Rua1Amar;
        private System.Windows.Forms.Button btn_Rua2Amar;
        private System.Windows.Forms.Button btn_Rua2Verm;
        private System.Windows.Forms.Button btn_Rua2Verd;
        private System.Windows.Forms.PictureBox pic_rua2;
        private System.Windows.Forms.PictureBox pic_rua1;
        private System.Windows.Forms.Label Lbl_Rua1;
        private System.Windows.Forms.Label Lbl_rua2;
        private System.Windows.Forms.TextBox txb_Dado_2;
        private System.Windows.Forms.TextBox txb_Dados;
        private System.Windows.Forms.Button button1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}

