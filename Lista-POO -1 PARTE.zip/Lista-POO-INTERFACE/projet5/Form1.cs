﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Milha_Km(object sender, EventArgs e)
        {
            Double milha, resul;
            milha = double.Parse(Txb1.Text);
            resul = milha * 1.852;
            Lbl3.Text = resul.ToString() + "Km";
            Lbl3.Visible = true;
        }
    }
}
