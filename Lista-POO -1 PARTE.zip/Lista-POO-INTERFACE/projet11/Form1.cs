﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Triangulo(object sender, EventArgs e)
        {
            double ld1, ld2, ld3;
            ld1 = double.Parse(Txb1.Text);
            ld2 = double.Parse(Txb2.Text);
            ld3 = double.Parse(Txb3.Text);
            if (ld1 + ld2 > ld3)
            {

                if (ld1 + ld3 > ld2)
                {

                    if (ld2 + ld3 > ld1)
                    {

                        if (ld1 == ld2)
                        {

                            if (ld1 == ld3)
                            {

                                Lbl4.Text = "Equilátero";
                            }
                            else
                                Lbl4.Text = "Isósceles";
                        }
                        else
                            if (ld2 == ld3)
                        {

                            Lbl4.Text = "Isósceles";
                        }
                        else
                                  if (ld1 == ld3)
                        {

                            Lbl4.Text = "Isósceles";
                        }
                        else
                            Lbl4.Text = "Escaleno";
                    }
                    else
                        Lbl4.Text = "Não forma triângulo";
                }
                else
                    Lbl4.Text = "Não forma triângulo";
            }
            else
                Lbl4.Text = "Não forma triângulo";

            Lbl4.Visible = true;
        }
    }
}
