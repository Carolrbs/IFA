﻿namespace projet11
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbl4 = new System.Windows.Forms.Label();
            this.Lbl2 = new System.Windows.Forms.Label();
            this.Txb2 = new System.Windows.Forms.TextBox();
            this.Btn1 = new System.Windows.Forms.Button();
            this.Lbl1 = new System.Windows.Forms.Label();
            this.Txb1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Txb3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Lbl4
            // 
            this.Lbl4.AutoSize = true;
            this.Lbl4.Location = new System.Drawing.Point(284, 281);
            this.Lbl4.Name = "Lbl4";
            this.Lbl4.Size = new System.Drawing.Size(13, 13);
            this.Lbl4.TabIndex = 13;
            this.Lbl4.Text = "0";
            this.Lbl4.Visible = false;
            // 
            // Lbl2
            // 
            this.Lbl2.AutoSize = true;
            this.Lbl2.Location = new System.Drawing.Point(350, 159);
            this.Lbl2.Name = "Lbl2";
            this.Lbl2.Size = new System.Drawing.Size(40, 13);
            this.Lbl2.TabIndex = 11;
            this.Lbl2.Text = "Valor 2";
            // 
            // Txb2
            // 
            this.Txb2.Location = new System.Drawing.Point(353, 187);
            this.Txb2.Name = "Txb2";
            this.Txb2.Size = new System.Drawing.Size(100, 20);
            this.Txb2.TabIndex = 10;
            // 
            // Btn1
            // 
            this.Btn1.Location = new System.Drawing.Point(287, 228);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(75, 23);
            this.Btn1.TabIndex = 9;
            this.Btn1.Text = "Calcular";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Triangulo);
            // 
            // Lbl1
            // 
            this.Lbl1.AutoSize = true;
            this.Lbl1.Location = new System.Drawing.Point(190, 159);
            this.Lbl1.Name = "Lbl1";
            this.Lbl1.Size = new System.Drawing.Size(40, 13);
            this.Lbl1.TabIndex = 8;
            this.Lbl1.Text = "Valor 1";
            // 
            // Txb1
            // 
            this.Txb1.Location = new System.Drawing.Point(190, 187);
            this.Txb1.Name = "Txb1";
            this.Txb1.Size = new System.Drawing.Size(100, 20);
            this.Txb1.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(473, 159);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Valor 3";
            // 
            // Txb3
            // 
            this.Txb3.Location = new System.Drawing.Point(476, 187);
            this.Txb3.Name = "Txb3";
            this.Txb3.Size = new System.Drawing.Size(100, 20);
            this.Txb3.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Txb3);
            this.Controls.Add(this.Lbl4);
            this.Controls.Add(this.Lbl2);
            this.Controls.Add(this.Txb2);
            this.Controls.Add(this.Btn1);
            this.Controls.Add(this.Lbl1);
            this.Controls.Add(this.Txb1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl4;
        private System.Windows.Forms.Label Lbl2;
        private System.Windows.Forms.TextBox Txb2;
        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Label Lbl1;
        private System.Windows.Forms.TextBox Txb1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Txb3;
    }
}

