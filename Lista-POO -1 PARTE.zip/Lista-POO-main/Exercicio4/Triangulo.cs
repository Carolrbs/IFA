﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio4
{
    internal class Triangulo
    {
        private int a;
        private int b;
        private int area;

        public void setA(int a)
        {
            this.a = a;
        }
        public void setB(int b) 
        {
            this.b = b; 
        }
        public int getA()
        {
            return this.a;
        }
        public int getB()
        {
            return this.b;
        }
        public int getArea()
        {
            return this.area;
        }
        public void areatrian()
        {
            this.area = (this.a * this.b) / 2;
        }
    }
}
