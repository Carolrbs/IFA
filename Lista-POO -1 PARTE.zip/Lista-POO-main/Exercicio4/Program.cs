﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Triangulo tri = new Triangulo();
            Console.Write("Digite o valor Base do triangulo: ");
            tri.setB(int.Parse(Console.ReadLine()));
            Console.Write("Digite o valor Altura do triangulo: ");
            tri.setA(int.Parse(Console.ReadLine()));
            tri.areatrian();
            Console.WriteLine("O valor da area do triangulo é: {0}", tri.getArea());
        }
    }
}
