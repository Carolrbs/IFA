﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercico3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Diagonal diago = new Diagonal();
            Console.Write("Digite o valor da diagonal: ");
            diago.setdiagonal(int.Parse(Console.ReadLine()));
            diago.areadiago();
            Console.WriteLine("O valor da area é: {0}", diago.getresul());
        }
    }
}
