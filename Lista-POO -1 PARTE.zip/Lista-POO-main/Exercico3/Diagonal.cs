﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercico3
{
    internal class Diagonal
    {
        private int diagonal;
        private int resul;

        public void setdiagonal(int diagonal)
        {
            this.diagonal = diagonal;
        }
        public int getdiagonal()
        {
            return this.diagonal;
        }
        public int getresul()
        {
            return this.resul;
        }
        public void areadiago()
        {
            this.resul = (this.diagonal * this.diagonal)/2;
        }

    }
}
