﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Aresta aresta = new Aresta();
            Console.Write("Digite o valor da Aresta: ");
            aresta.setAresta(int.Parse(Console.ReadLine()));
            aresta.Arestaarea();
            Console.WriteLine("O valor da area é: {0}",aresta.getArea());
        }
    }
}
