﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calcular_area(object sender, EventArgs e)
        {
            double are, bas, resul;
            are = double.Parse(Txb1.Text);
            bas = double.Parse(Txb2.Text);
            resul = are * bas;
            if (resul > 100)
            {
               Lbl4.Text = "Terreno grande";
            }
            else
            {
                Lbl4.Text = "Terreno pequeno";
            }
            Lbl4.Visible = true;
        }
    }
}
