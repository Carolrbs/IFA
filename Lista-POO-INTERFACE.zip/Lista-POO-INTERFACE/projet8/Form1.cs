﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Maior_Valor(object sender, EventArgs e)
        {
            double vl1, vl2, resul;
            vl1 = double.Parse(Txb1.Text);
            vl2 = double.Parse(Txb2.Text);

            if (vl1 > vl2)
            {
                resul = vl1;
                Lbl4.Text = "o primeiro: " + vl1.ToString();
                Lbl3.Text = "O maior é";
                Lbl3.Visible = true;
                Lbl4.Visible = true;
            }
            else if (vl1 < vl2)
            {
                resul = vl2;
                Lbl4.Text = "o segundo: " + vl2.ToString();
                Lbl3.Text = "O maior é";
                Lbl3.Visible = true;
                Lbl4.Visible = true;
            }
            else
            {
                Lbl3.Text = "Os valores são iguais.";
                Lbl3.Visible = true;

            }
        }
    }
}
