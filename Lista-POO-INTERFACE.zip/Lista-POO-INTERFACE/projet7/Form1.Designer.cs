﻿namespace projet7
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txb1 = new System.Windows.Forms.TextBox();
            this.Lbl1 = new System.Windows.Forms.Label();
            this.Btn1 = new System.Windows.Forms.Button();
            this.Txb2 = new System.Windows.Forms.TextBox();
            this.Lbl2 = new System.Windows.Forms.Label();
            this.Lbl3 = new System.Windows.Forms.Label();
            this.Lbl4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Txb1
            // 
            this.Txb1.Location = new System.Drawing.Point(182, 179);
            this.Txb1.Name = "Txb1";
            this.Txb1.Size = new System.Drawing.Size(100, 20);
            this.Txb1.TabIndex = 0;
            // 
            // Lbl1
            // 
            this.Lbl1.AutoSize = true;
            this.Lbl1.Location = new System.Drawing.Point(182, 151);
            this.Lbl1.Name = "Lbl1";
            this.Lbl1.Size = new System.Drawing.Size(40, 13);
            this.Lbl1.TabIndex = 1;
            this.Lbl1.Text = "Valor 1";
            // 
            // Btn1
            // 
            this.Btn1.Location = new System.Drawing.Point(279, 220);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(75, 23);
            this.Btn1.TabIndex = 2;
            this.Btn1.Text = "Calcular";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Descobrir_Maior);
            // 
            // Txb2
            // 
            this.Txb2.Location = new System.Drawing.Point(345, 179);
            this.Txb2.Name = "Txb2";
            this.Txb2.Size = new System.Drawing.Size(100, 20);
            this.Txb2.TabIndex = 3;
            // 
            // Lbl2
            // 
            this.Lbl2.AutoSize = true;
            this.Lbl2.Location = new System.Drawing.Point(342, 151);
            this.Lbl2.Name = "Lbl2";
            this.Lbl2.Size = new System.Drawing.Size(40, 13);
            this.Lbl2.TabIndex = 4;
            this.Lbl2.Text = "Valor 2";
            // 
            // Lbl3
            // 
            this.Lbl3.AutoSize = true;
            this.Lbl3.Location = new System.Drawing.Point(222, 273);
            this.Lbl3.Name = "Lbl3";
            this.Lbl3.Size = new System.Drawing.Size(55, 13);
            this.Lbl3.TabIndex = 5;
            this.Lbl3.Text = "O maior é:";
            // 
            // Lbl4
            // 
            this.Lbl4.AutoSize = true;
            this.Lbl4.Location = new System.Drawing.Point(276, 273);
            this.Lbl4.Name = "Lbl4";
            this.Lbl4.Size = new System.Drawing.Size(13, 13);
            this.Lbl4.TabIndex = 6;
            this.Lbl4.Text = "0";
            this.Lbl4.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Lbl4);
            this.Controls.Add(this.Lbl3);
            this.Controls.Add(this.Lbl2);
            this.Controls.Add(this.Txb2);
            this.Controls.Add(this.Btn1);
            this.Controls.Add(this.Lbl1);
            this.Controls.Add(this.Txb1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txb1;
        private System.Windows.Forms.Label Lbl1;
        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.TextBox Txb2;
        private System.Windows.Forms.Label Lbl2;
        private System.Windows.Forms.Label Lbl3;
        private System.Windows.Forms.Label Lbl4;
    }
}

