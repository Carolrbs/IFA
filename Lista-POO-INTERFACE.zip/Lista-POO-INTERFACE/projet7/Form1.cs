﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projet7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Descobrir_Maior(object sender, EventArgs e)
        {
            int Valor1, Valor2, Maior;
            Valor1 = int.Parse(Txb1.Text);
            Valor2 = int.Parse(Txb2.Text);


            if (Valor1 > Valor2)
            {
                Maior = Valor1;
                Lbl4.Text = Maior.ToString();
                Lbl4.Visible = true;
            }
            else if (Valor1 < Valor2)
            {
                Maior = Valor2;
                Lbl4.Text = Maior.ToString();
                Lbl4.Visible = true;
            }

        }
    }
}
